<?php $__env->startSection('content'); ?>
<div class="py-5"></div>
<div class="container">
    <?php if(Session::has('message')): ?>
        <div class="alert alert-danger">
            <?php echo e(Session::get('message')); ?>

        </div>
    <?php endif; ?>
    <div class="row justify-content-center">
        <div class="col">
            <div class="card">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                    <div class="container">
                        <div class="rounded">
                            <div class="row">
                                <div class="col">
                                    <?php if(Auth::user()->privilege=='exhibitor'): ?>
                                        <a href="<?php echo e(route('exhibitions.create')); ?>">
                                            <button class="btn btn-success">Post Exhibition</button>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <input type="text" name="srchexb" id="" class="form-control" placeholder="Kata Kunci">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="py-2"></div>
                        <?php $__currentLoopData = $exhibitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <div class="border p-3 bg-white rounded">
                                <div class="row">
                                    <div class="col-2 text-center align-self-center">
                                        <a href="<?php echo e(route('exhibitions.show', [$exhibition->id, $exhibition->slug])); ?>">
                                            <img class="" src="<?php echo e(asset('avatar')); ?>/<?php echo e($exhibition->exhibitor->logo); ?>" alt="" style="max-width:100px; position:relative;">
                                        </a>
                                    </div>
                                    <div class="col-7">
                                        <div class="py-2"></div>
                                        <a href="<?php echo e(route('exhibitions.show', [$exhibition->id, $exhibition->slug])); ?>" class="font-weight-bold h4"><?php echo e($exhibition->name); ?></a>
                                        <div class="py-1"></div>
                                        <?php $date=date_create($exhibition->start_date); echo date_format($date,"l, d-F-Y"); ?> - <?php $date=date_create($exhibition->end_date); echo date_format($date,"l, d-F-Y"); ?>
                                        <div class="py-1"></div>
                                        <i class="fa fa-calendar-check"></i> <?php echo e($exhibition->created_at->diffForHumans()); ?>  
                                    </div>
                                    <div class="col-1 form-inline">
                                        <a class="" href="<?php echo e(route('exhibitions.show', [$exhibition->id, $exhibition->slug])); ?>"> <!--Mengarahkan untuk menampilkan detail dari exhibition  -->
                                            <button type="submit" class="btn btn-outline-success">Detail</button>
                                        </a>
                                        <a class="" href="/exhibitions/<?php echo e($exhibition->id); ?>/<?php echo e($exhibition->slug); ?>/edit"> <!--Mengarahkan untuk menampilkan detail dari exhibition  -->
                                            <button type="submit" class="btn btn-outline-warning">Edit</button>
                                        </a> 
                                        
                                        <form action="<?php echo e($exhibition->id); ?>" method="post">
                                            <?php echo method_field('delete'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-outline-danger">Delete</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                              <div class="py-1"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="py-5"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\jobit2-2\resources\views/exhibitions/myexhibitions.blade.php ENDPATH**/ ?>