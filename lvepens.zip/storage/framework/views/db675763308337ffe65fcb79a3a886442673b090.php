<?php $__env->startSection('content'); ?>
<div class="py-5"></div>
<div class="container">
    <div class="card-exhibitor">
        <div class="exhibitor-profile">
            <img style=" width: 100%; " src="<?php echo e(asset('cover')); ?>/<?php echo e($exhibitor->coverphoto); ?>" alt="" >
        </div>
        <div class="atas">
            <div class="exhibitor-desc"> 
                <div class="row">
                    <div class="col">
                        <img class="img-exhibitor rounded-lg" style=" " src="<?php echo e(asset('avatar')); ?>/<?php echo e($exhibitor->logo); ?>" alt="" width="200px">
                    </div>
                    <div class="col">
                        <span class="align-text-bottom text-center rounded ">
                            <h1 class="bg-light "><?php echo e($exhibitor->ename); ?></h1>
                        </span>
                    </div>
                </div>
                <div class="py-2"></div>
                <div class="exhibitor-desc-write">
                    
                    <div class="py-2"></div>
                    <p class="text-justify"> <?php echo $exhibitor->description ?></p>
                    <table>
                        <tr>
                            <td>Website URL</td>
                            <td>:</td>
                            <td class="text-break"><a href="http://<?php echo e($exhibitor->website_url); ?>" target="_blank"><?php echo e($exhibitor->website_url); ?></a></td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td class="text-break"><?php echo e($exhibitor->address); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        
        

    </div>
    <div class="py-2"></div>
    <div class="card-exhibitor">
        <table class="table ">
            <thead class="thead-exhibitor">
               <th colspan="5"> Daftar Kegiatan</th>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <div class="container">
                            <?php $__currentLoopData = $exhibitor->exhibitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exhibition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <div class="border p-3 bg-white rounded">
                                    <div class="row">
                                        <div class="col-2 text-center align-self-center">
                                            <a href="<?php echo e(route('exhibitions.show', [$exhibition->id, $exhibition->slug])); ?>">
                                                <img class="" src="<?php echo e(asset('avatar')); ?>/<?php echo e($exhibition->exhibitor->logo); ?>" alt="" style="max-width:100px; position:relative;">
                                            </a>
                                        </div>
                                        <div class="col-7">
                                            <div class="py-2"></div>
                                            <a href="<?php echo e(route('exhibitions.show', [$exhibition->id, $exhibition->slug])); ?>" class="font-weight-bold h4"><?php echo e($exhibition->name); ?></a>
                                            <div class="py-1"></div>
                                            <?php $date=date_create($exhibition->start_date); echo date_format($date,"l, d-F-Y"); ?> - <?php $date=date_create($exhibition->end_date); echo date_format($date,"l, d-F-Y"); ?>
                                            <div class="py-1"></div>
                                            <i class="fa fa-calendar-check"></i> <?php echo e($exhibition->created_at->diffForHumans()); ?>  
                                        </div>
                                        <div class="col-1 form-inline">
                                            <a class="" href="<?php echo e(route('exhibitions.show', [$exhibition->id, $exhibition->slug])); ?>">
                                                <button type="submit" class="btn btn-outline-success">Detail</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                              <div class="py-1"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </div>
                        
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\jobit2-2\resources\views/exhibitor/index.blade.php ENDPATH**/ ?>